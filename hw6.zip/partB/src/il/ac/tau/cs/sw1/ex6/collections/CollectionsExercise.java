package il.ac.tau.cs.sw1.ex6.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionsExercise {

	/* @pre: mapsList.size() > 0 */
	public static Map<Character, Integer> processDicts(List<Map<Character, Set<String>>> mapsList) {
		Map<Character, Integer> proceesedMap = new HashMap<>();

		// Iterate through all maps
			for (Map<Character, Set<String>> dict : mapsList) {
				if (dict == null) {
					continue; // Skip null maps
				}

				for (Map.Entry<Character, Set<String>> entry : dict.entrySet()) {
					char key = entry.getKey();
					Set<String> valueSet = entry.getValue();

					// Ensure the key is present in the processed map with default count
					proceesedMap.putIfAbsent(key, 0);

					if (valueSet == null || valueSet.isEmpty()) {
						continue; // Skip empty or null value sets
					}

					// Count how many maps contain this key and at least one value
					int count = 0;
					for (Map<Character, Set<String>> innerDict : mapsList) {
						if (innerDict != null && innerDict.containsKey(key)) {
							Set<String> innerValues = innerDict.get(key);
							if (innerValues == null) {
								continue; // Skip null value sets
							}

							// Check if there is any intersection between the two sets
							boolean matchFound = false;
							for (String value : valueSet) {
								if (innerValues.contains(value)) {
									matchFound = true;
									break; // Found a match, stop checking further
								}
							}

							if (matchFound) {
								count++;
							}
						}
					}

					// Update the processed map with the max count
					proceesedMap.put(key, count);
				}
			}

			return proceesedMap;
	}



	/* @pre p is prime */
	public static List<Integer> weirdSort(List<Integer> lst, int p) {
		List<Integer> sortedList = new ArrayList<>(lst);

		// Sort based on the cosine of (number % p)
		Collections.sort(sortedList, (a, b) -> {
			double cosA = Math.cos(a % p);
			double cosB = Math.cos(b % p);
			return Double.compare(cosA, cosB);
		});

		return sortedList;
	}

}








