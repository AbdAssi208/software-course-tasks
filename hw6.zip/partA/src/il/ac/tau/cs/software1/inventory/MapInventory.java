package il.ac.tau.cs.software1.inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MapInventory implements Inventory {
	
	private Map<Float, List<Collectible>> map;
	private int numOfItems;
	private float totalWeight;
	
	public MapInventory()
	{
		map = new HashMap<Float, List<Collectible>>();
		numOfItems = 0;
		totalWeight = 0;
	}

	@Override
	public Iterator<Collectible> iterator() 
	{
		MapInventoryIterator MPITR = new MapInventoryIterator(this);
		return MPITR;
	}
	
	@Override
	public void collect(Collectible collectible) 
	{
	    map.putIfAbsent(collectible.getPrice(), new ArrayList<>());
	    map.get(collectible.getPrice()).add(collectible);
	    numOfItems++;
	    totalWeight += collectible.getWeight();
	}

	@Override
	public float getTotalWeight() 
	{
		return totalWeight;
	}
	
	@Override
	public int getCurrentCount() 
	{
		return numOfItems;
	}

	public Map<Float, List<Collectible>> get_map() {
		return map;
	}
	
			
}
