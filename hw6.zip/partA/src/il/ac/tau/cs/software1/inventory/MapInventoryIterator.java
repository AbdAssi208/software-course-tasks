package il.ac.tau.cs.software1.inventory;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public class MapInventoryIterator implements Iterator<Collectible> {

    private MapInventory MP;
    private Iterator<Entry<Float, List<Collectible>>> itr;
    private Iterator<Collectible> curr_item;
    private Entry<Float, List<Collectible>> curr_price;
    private int counted;

    public MapInventoryIterator(MapInventory mp) {
        MP = mp;
        curr_price = null;
        curr_item = null;
        itr = mp.get_map().entrySet().iterator();
        counted = 0;
    }

    @Override
    public boolean hasNext() 
    {
       return (counted < MP.getCurrentCount()) ;
    }

    @Override
    public Collectible next() {
        if (!hasNext()) {
            throw new NoSuchElementException();  
        }

 
        while ((curr_item == null || !curr_item.hasNext()) && itr.hasNext()) {
            curr_price = itr.next();  
            curr_item = curr_price.getValue().iterator();  
        }

        if (curr_item == null || !curr_item.hasNext()) {
            throw new NoSuchElementException();  
        }

        counted++;  
        return curr_item.next();
    }
    
}
