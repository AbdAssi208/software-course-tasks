package il.ac.tau.cs.software1.components;

public interface IComponent {
}
