package il.ac.tau.cs.software1.inventory;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class NaiveInventoryIterator implements Iterator<Collectible> {
	
	private NaiveInventory NV;
	private int curr_item;
	
	NaiveInventoryIterator(NaiveInventory nv)
	{
		NV = nv;
		curr_item = 0;
	}
	@Override
	public boolean hasNext() {
		if (curr_item < NV.getCurrentCount()) 
		{
			return true;
		}
		return false;
	}

	@Override
	public Collectible next() {
	    if (!hasNext()) {
	        throw new NoSuchElementException();
	    }
	    return NV.getCollArr()[curr_item++];
	}
	
	

}
