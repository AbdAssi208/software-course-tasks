package il.ac.tau.cs.software1.core;

public enum EInputType {
	INPUT_UP,
	INPUT_DOWN,
	INPUT_LEFT,
	INPUT_RIGHT,
	INPUT_SELECT,
	INPUT_QUIT
}
