# HW6
# SW1-Pacman
Java implementation of the classical Pacman game using themes from OOP for the course Software 1, taught at Tel Aviv University.
