package il.ac.tau.cs.software1.pacman;

import il.ac.tau.cs.software1.math.*;
import il.ac.tau.cs.software1.core.*;
import il.ac.tau.cs.software1.components.*;

public class PacmanGhost extends PacmanGameObject {
	// TOOD: Implement behavior! In class we'll talk on how to approach this.
	protected ImageComponent regularImageComponent;
	protected ImageComponent scaredImageComponent;
	protected boolean isScared = false;
	
	public PacmanGhost(PacmanGridComponent initialPosition) {
		super(initialPosition);
		regularImageComponent = new ImageComponent("ghost");
		scaredImageComponent = new ImageComponent("ghost-scared");
		setScared(false);
		
		EventManager.getInstance().subscribe("potionCollected", this, (EventData data) -> {
	        if (data != null && data.publisher != null) {
	            TransformComponent transform = data.publisher.getTransformComponent();
	            if (transform != null) {
	                Vector2 position = transform.position;
	                System.out.println("Collected potion @ " + position.toString());
	            }
	        } else {
	            System.err.println("Error: EventData or publisher is null");
	        }

	        if (!isScared) {
	            setScared(true);
	        } else {
	            setScared(false);
	        }
	    });}
	
	protected void setScared(boolean scared) {
		isScared = scared;
		imageComponent = isScared ? scaredImageComponent : regularImageComponent;
	}
	
	public boolean getScared() {
		return isScared;
	}
	
}
