package il.ac.tau.cs.software1.core;

import java.util.*;

public class EventManager {
	Map<String, List<EventSubscription>> subscribers = new HashMap<>();
	
	public void subscribe(String event, GameObject subscriber, IEventCallback callback) { 
		   
		   subscribers.putIfAbsent(event, new ArrayList<>());

		   EventSubscription subscription = new EventSubscription(subscriber, callback);

		   subscribers.get(event).add(subscription);
		}
	
	public void notifyEvent(String event, GameObject publisher, Object data) {

		    if (!subscribers.containsKey(event)) {
		        return;
		    }

		    for (EventSubscription subscription : subscribers.get(event)) {
		    	
		        if (data instanceof EventData || data == null) {
		            subscription.callback.call((EventData) data);
		        }
		    }
	}
	

	private static EventManager instance;
	
	private EventManager() {}

	public static EventManager getInstance() {
	      if (instance == null) {
	           instance = new EventManager();
	      }
	        return instance;
	}
	

}
