package il.ac.tau.cs.software1.core;

public interface IObjectFilter {
	public boolean filter(GameObject obj);
}
