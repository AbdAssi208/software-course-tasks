package il.ac.tau.cs.software1.core;

public interface IEventCallback {
	public void call(EventData data);
}
